// let randomColor = Math.floor(Math.random() * 16777215).toString(16);
// export const Color = `#${randomColor}`;

// export const Color = "#F73859";
// export const Color = "#7b68ee";
export const Color = "#1FBA30";
// export const Color = "rgb(81, 91, 228)";
// export const Color = "tomato";
