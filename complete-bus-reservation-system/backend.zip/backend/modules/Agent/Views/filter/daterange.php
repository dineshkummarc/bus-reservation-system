<div class="col-4">
    <?php echo $this->include('common/filter/daterangefrom') ?>
</div>

<div class="col-4">
    <?php echo $this->include('common/filter/daterangeto') ?>
</div>

<div class="col-4 mt-2">
<br>
    <button type="submit" class="btn btn-success"><?php echo lang("Localize.submit") ?></button>
</div>