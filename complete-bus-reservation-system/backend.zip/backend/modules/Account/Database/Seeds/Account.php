<?php

namespace Modules\Account\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Account extends Seeder
{
	public function run()
	{
		//
	}
}
