import styled from "styled-components";

export const SingleButton = styled.button`
  cursor: pointer;
`;
