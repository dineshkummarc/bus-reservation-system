<?php

namespace Modules\Localize\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Localize extends Seeder
{
	public function run()
	{
		//
	}
}
