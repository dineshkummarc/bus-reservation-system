<?php

namespace Modules\Fitness\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Fitness extends Seeder
{
	public function run()
	{
		//
	}
}
