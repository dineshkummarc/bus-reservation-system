import styled from "styled-components";

export const Text = styled.span`
  background: red;
  color: white;
  padding: 10px;
  border-radius: 10px;
  transitionduration: 0.2s;
`;
