<?php

namespace Modules\Employee\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Employee extends Seeder
{
	public function run()
	{
		//
	}
}
