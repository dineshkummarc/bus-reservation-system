<?php

return [
    'page_title' => 'Pagina de bienvenida',
    'welcome_message' => 'Hola bienvenido a esta pagina',
    'author_information' => 'Mi nombre es Sanjay. Este blog es mío y creamos esta publicación para que aprendas.',
];
