<?php

namespace Modules\Fleet\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Fleet extends Seeder
{
	public function run()
	{
		//
	}
}
