<?php

namespace Modules\Account\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Accounthead extends Seeder
{
	public function run()
	{
		//
	}
}
