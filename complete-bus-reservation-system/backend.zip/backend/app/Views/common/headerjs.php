<script src="<?php echo base_url('public/js/jquery3.6.0.js'); ?>"></script>
<script src="<?php echo base_url('public/js/bootstrap/js/bootstrap.bundle.min.js');?>"></script>