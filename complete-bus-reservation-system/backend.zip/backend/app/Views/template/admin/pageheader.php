                        <!-- <div class="page-header m-0">
                       <?php
                           $uri = service('uri');
                       
                           $function = $uri->getSegment(2);
                       ?>
                            <h4 class="page-title text-capitalize"><?php echo  $module ?? $uri->getSegment(1) ;?></h4>
                        
                            <ul class="breadcrumbs">
                                <li class="nav-home">
                                    <a href="#">
                                        <i class="typcn typcn-home-outline"></i>
                                    </a>
                                </li>
                                <li class="separator">
                                    <i class="ti-angle-right"></i>
                                    
                                </li>
                                <li class="nav-item">
                                    <a href="#"><?php echo  $title ?? $uri->getSegment(2);?></a>
                                </li>
                                
                            </ul>
                        </div> -->