import styled from "styled-components";

export const NotFoundPageTitle = styled.h1`
  text-align: center;
`;
