import styled from "styled-components";

export const Container = styled.div`
  padding: 20px 0px;
  font-size: 12px;
`;
