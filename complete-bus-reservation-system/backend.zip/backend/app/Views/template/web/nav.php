

<!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        
        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Location
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li>  <a class="dropdown-item" href="<?= base_url(route_to( 'new-location' )) ?>">Add Location</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-location' )) ?>">Location List</a></li>
          
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Fleet Management
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-fleet' )) ?>">Add Fleet Type</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-fleet' )) ?>">Fleet List</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-Vehicle' )) ?>">Add Vehicle</a></li>
            <li> <a class="dropdown-item" href="<?= base_url(route_to( 'index-Vehicle' )) ?>">Vehicle List</a></li>
          </ul>
        </li>



        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Employee
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-employeetype' )) ?>">Add Employee Type</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-employeetype' )) ?>">Employee Type List</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-Employee' )) ?>">Add Employee </a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-Employee' )) ?>">Employee List</a></li>
          </ul>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Schedule 
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-schedule' )) ?>">Add schedule </a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-employeetype' )) ?>">Schedule List</a></li>
            
          </ul>
        </li>


        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
          Trip 
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'new-trip' )) ?>">Add trip </a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'index-trip' )) ?>">trip List</a></li>
            <li><a class="dropdown-item" href="<?= base_url(route_to( 'findtrip-trip' )) ?>">Find trip List</a></li>
            
          </ul>
        </li>

      </ul>
    </div>
  </div>
</nav> -->





<!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" href="<?= base_url(route_to( 'login' )) ?>" aria-current="page" href="#">LOGIN</a>
        </li>
        


      </ul>
    </div>
  </div>
</nav> -->


