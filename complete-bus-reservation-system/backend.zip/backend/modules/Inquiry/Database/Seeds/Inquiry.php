<?php

namespace Modules\Inquiry\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Inquiry extends Seeder
{
	public function run()
	{
		//
	}
}
