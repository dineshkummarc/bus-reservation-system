<?php

namespace Modules\Localize\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Lngstngvalue extends Seeder
{
	public function run()
	{
		//
	}
}
