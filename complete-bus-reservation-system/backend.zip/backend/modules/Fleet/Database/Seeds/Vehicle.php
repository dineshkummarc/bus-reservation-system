<?php

namespace Modules\Fleet\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Vehicle extends Seeder
{
	public function run()
	{
		//
	}
}
