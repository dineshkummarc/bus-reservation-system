<?php

namespace Modules\Agent\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Agent extends Seeder
{
	public function run()
	{
		//
	}
}
