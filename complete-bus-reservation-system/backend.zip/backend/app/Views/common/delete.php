<input type="hidden"  name ="<?php echo csrf_token(); ?>" value="<?php echo csrf_hash(); ?>">
		<input type="hidden" name="_method" value="delete" />