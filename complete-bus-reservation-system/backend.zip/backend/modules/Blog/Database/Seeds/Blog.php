<?php

namespace Modules\Blog\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Blog extends Seeder
{
	public function run()
	{
		//
	}
}
