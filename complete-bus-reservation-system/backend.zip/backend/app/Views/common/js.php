<script src="<?php echo base_url('public/js/ajax.js'); ?>"></script>
<script src="<?php echo base_url('public/js/bootstrap-datepicker.js'); ?>"></script>
<script src="<?php echo base_url('public/js/clockpicker.min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/jquery.sumoselect.min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/multipleselect.js'); ?>"></script>
<script src="<?php echo base_url('public/js/spartan-multi-image-picker-min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/imagepicker.js'); ?>"></script>
<script src="<?php echo base_url('public/js/timepick.js'); ?>"></script>
<script src="<?php echo base_url('public/js/metisMenu/metisMenu.min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/perfect-scrollbar/dist/perfect-scrollbar.min.js'); ?>"></script> 

<!-- counter up -->
<script src="<?php echo base_url('public/js/counterup/jquery.waypoints.min.js'); ?>"></script>
<script src="<?php echo base_url('public/js/counterup/jquery.counterup.min.js'); ?>"></script>
<!-- counter up -->

<!-- data table -->
<script src="<?php echo base_url('public/datatables/datatables.min.js'); ?>"></script>
<script src="<?php echo base_url('public/datatables/Buttons-2.0.1/js/dataTables.buttons.js'); ?>"></script>
<script src="<?php echo base_url('public/datatables/JSZip-2.5.0/jszip.min.js'); ?>"></script>
<script src="<?php echo base_url('public/datatables/pdfmake-0.1.36/pdfmake.min.js'); ?>"></script>
<script src="<?php echo base_url('public/datatables/pdfmake-0.1.36/vfs_fonts.js'); ?>"></script>

<script src="<?php echo base_url('public/datatables/Buttons-2.0.1/js/buttons.html5.min.js'); ?>"></script>
<script src="<?php echo base_url('public/datatables/Buttons-2.0.1/js/buttons.print.js'); ?>"></script>

<script src="<?php echo base_url('public/js/mydatatable.js'); ?>"></script>
<!-- data table -->

<!-- message hide -->
<script src="<?php echo base_url('public/js/message.js'); ?>"></script>
<!-- message hide -->

<script src="<?php echo base_url('public/js/sidebar.js'); ?>"></script>
<script src="<?php echo base_url('public/js/bus365datapick.js'); ?>"></script>

<!-- datapicker -->

<!-- datapicker -->

<script src="<?php echo base_url('public/js/common.js'); ?>"></script>
