<?php

namespace Modules\Add\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Add extends Seeder
{
	public function run()
	{
		//
	}
}
