import styled from "styled-components";

export const BusPhotoWrapper = styled.div`
  padding: 20px 0px;
  display: grid;
  grid-template-columns: 48% 48%;
  grid-gap: 4%;
`;
