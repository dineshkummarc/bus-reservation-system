<?php

namespace Modules\Location\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Location extends Seeder
{
	public function run()
	{
		//
	}
}
