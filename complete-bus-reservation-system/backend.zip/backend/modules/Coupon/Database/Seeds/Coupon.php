<?php

namespace Modules\Coupon\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Coupon extends Seeder
{
	public function run()
	{
		//
	}
}
