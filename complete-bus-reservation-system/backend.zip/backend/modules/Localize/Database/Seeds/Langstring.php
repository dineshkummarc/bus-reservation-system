<?php

namespace Modules\Localize\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Langstring extends Seeder
{
	public function run()
	{
		//
	}
}
