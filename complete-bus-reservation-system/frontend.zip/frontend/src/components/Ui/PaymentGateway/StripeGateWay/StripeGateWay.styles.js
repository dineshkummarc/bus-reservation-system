import styled from "styled-components";

export const StripeWrapper = styled.div``;
