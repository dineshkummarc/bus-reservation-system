import styled from "styled-components";

export const SingleImage = styled.img`
  max-width: 100%;
  height: auto;
`;
