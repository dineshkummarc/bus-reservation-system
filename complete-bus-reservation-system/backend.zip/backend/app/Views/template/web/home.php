<?php echo $this->extend('template/web/main') ?>

<?php echo $this->section('content') ?>
    

<h1 class="text-center text-dark text-capitalize ">
welcome to bus 365
</h1>

<?php echo $this->endSection() ?>